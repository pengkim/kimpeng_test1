import os
import uuid
import datetime
import requests
from flask import (Blueprint, render_template, request, redirect,
                   url_for, flash, session, send_from_directory, abort)
from database import get_db
from functools import wraps

board_bp = Blueprint('board', __name__, url_prefix='/board')

UPLOAD_DIR = os.path.abspath(
    os.path.join(os.path.dirname(os.path.dirname(__file__)), 'uploads', 'board')
)
ALLOWED_EXT = {'pdf', 'xlsx', 'xls', 'docx', 'doc', 'pptx', 'ppt',
               'txt', 'png', 'jpg', 'jpeg', 'gif', 'zip', 'csv', 'hwp', 'hwpx'}
MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB

# 읽음 추적 대상 카테고리
READ_TRACK_CATEGORIES = {'company_notice', 'team_notice'}

CATEGORIES = {
    'company_notice': {
        'label': '사내 공지사항',
        'icon':  '🏢',
        'color': '#1428A0',
        'bg':    '#EEF1FB',
        'desc':  'Flex 연동 사내 공지',
        'write_roles':  [],
        'delete_roles': ['admin'],
        'comment':      False,
    },
    'team_notice': {
        'label': '팀 공지사항',
        'icon':  '📢',
        'color': '#FF9F0A',
        'bg':    '#FFF8E1',
        'desc':  '팀 내부 공지 (관리자 작성)',
        'write_roles':  ['admin'],
        'delete_roles': ['admin'],
        'comment':      True,
    },
    'onboarding': {
        'label': '신규 입사자 자료',
        'icon':  '🎉',
        'color': '#30D158',
        'bg':    '#E8F5E9',
        'desc':  '입사자 온보딩 자료 (전원 업/다운로드)',
        'write_roles':  ['admin', 'member'],
        'delete_roles': ['admin', 'member'],
        'comment':      True,
    },
    'pc_setup': {
        'label': 'PC 환경 세팅 자료',
        'icon':  '💻',
        'color': '#0A84FF',
        'bg':    '#E3F2FD',
        'desc':  'PC 환경설정 가이드 (전원 업/다운로드)',
        'write_roles':  ['admin', 'member'],
        'delete_roles': ['admin', 'member'],
        'comment':      True,
    },
}

# ── 데코레이터 ────────────────────────────────────────
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('user_id'):
            return redirect(url_for('main.index'))
        return f(*args, **kwargs)
    return decorated

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if session.get('role') != 'admin':
            flash('관리자만 접근할 수 있습니다.', 'error')
            return redirect(url_for('board.hub'))
        return f(*args, **kwargs)
    return decorated

# ── 헬퍼 함수 ─────────────────────────────────────────
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXT

def file_size_str(size):
    if size < 1024:
        return f'{size}B'
    elif size < 1024 * 1024:
        return f'{size // 1024}KB'
    else:
        return f'{size / 1024 / 1024:.1f}MB'

def can_write(category):
    cat = CATEGORIES.get(category, {})
    roles = cat.get('write_roles', [])
    if not roles:
        return False
    return session.get('role') in roles

def can_delete_post(post):
    if session.get('role') == 'admin':
        return True
    cat = CATEGORIES.get(post['category'], {})
    roles = cat.get('delete_roles', [])
    if 'member' in roles and post['author_id'] == session.get('user_id'):
        return True
    return False

def get_file_icon(filename):
    ext = filename.rsplit('.', 1)[-1].lower() if '.' in filename else ''
    icons = {
        'png': '🖼️', 'jpg': '🖼️', 'jpeg': '🖼️', 'gif': '🖼️',
        'pdf': '📄', 'xlsx': '📊', 'xls': '📊', 'csv': '📊',
        'docx': '📝', 'doc': '📝', 'pptx': '📑', 'ppt': '📑',
        'zip': '🗜️', 'hwp': '📋', 'hwpx': '📋', 'txt': '📃',
    }
    return icons.get(ext, '📁')

def three_days_ago_str():
    return (datetime.datetime.now() - datetime.timedelta(days=3)).strftime('%Y-%m-%d %H:%M:%S')

# ── 읽음 처리 ─────────────────────────────────────────
def mark_as_read(db, post_id, user_id):
    """게시글을 읽음으로 표시 (중복 무시)"""
    try:
        db.execute(
            "INSERT OR IGNORE INTO board_reads (post_id, user_id) VALUES (?, ?)",
            (post_id, user_id)
        )
    except Exception:
        pass

# ── Flex 연동 ─────────────────────────────────────────
def get_flex_config():
    db = get_db()
    row = db.execute("SELECT * FROM flex_config ORDER BY id DESC LIMIT 1").fetchone()
    db.close()
    return dict(row) if row else {}

def sync_flex_notices():
    cfg = get_flex_config()
    if not cfg.get('is_enabled') or not cfg.get('api_url') or not cfg.get('api_key'):
        return 0, 'Flex 연동이 설정되지 않았습니다.'
    try:
        headers = {
            'Authorization': f"Bearer {cfg['api_key']}",
            'Content-Type': 'application/json',
        }
        resp = requests.get(
            cfg['api_url'].rstrip('/') + '/notices',
            headers=headers, timeout=15, verify=False,
        )
        if resp.status_code != 200:
            return 0, f'Flex API 오류: HTTP {resp.status_code}'
        data = resp.json()
        notices = data.get('notices', data if isinstance(data, list) else [])
        db = get_db()
        admin = db.execute("SELECT id FROM users WHERE role='admin' LIMIT 1").fetchone()
        admin_id = admin['id'] if admin else 1
        count = 0
        for item in notices:
            flex_id = str(item.get('id', ''))
            if not flex_id:
                continue
            exists = db.execute(
                "SELECT id FROM board_posts WHERE flex_id=?", (flex_id,)
            ).fetchone()
            if exists:
                continue
            title   = item.get('title', '(제목 없음)')
            content = item.get('content', item.get('body', ''))
            raw_dt  = item.get('created_at', item.get('createdAt', ''))
            try:
                dt = datetime.datetime.fromisoformat(raw_dt).strftime('%Y-%m-%d %H:%M:%S')
            except Exception:
                dt = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            db.execute('''
                INSERT INTO board_posts
                    (category, title, content, author_id, is_flex, flex_id, created_at, updated_at)
                VALUES (?, ?, ?, ?, 1, ?, ?, ?)
            ''', ('company_notice', title, content, admin_id, flex_id, dt, dt))
            count += 1
        db.execute("UPDATE flex_config SET last_sync=datetime('now','localtime')")
        db.commit()
        db.close()
        return count, None
    except requests.exceptions.ConnectionError:
        return 0, 'Flex 서버에 연결할 수 없습니다.'
    except requests.exceptions.Timeout:
        return 0, 'Flex API 연결 시간 초과 (15초).'
    except Exception as e:
        return 0, f'오류: {str(e)}'

# ── 사이드바용 N 뱃지 헬퍼 ───────────────────────────
def get_new_post_count(user_id):
    """
    3일 이내 새 게시글 중 현재 사용자가 아직 읽지 않은 글 수.
    읽음 추적 대상(사내공지/팀공지)만 카운트.
    """
    db = get_db()
    cutoff = three_days_ago_str()
    # READ_TRACK_CATEGORIES 에 해당하는 글만 카운트
    placeholders = ','.join('?' * len(READ_TRACK_CATEGORIES))
    params = [cutoff] + list(READ_TRACK_CATEGORIES) + [user_id]
    row = db.execute(f'''
        SELECT COUNT(*) as cnt
        FROM board_posts p
        WHERE p.created_at >= ?
          AND p.category IN ({placeholders})
          AND NOT EXISTS (
              SELECT 1 FROM board_reads r
              WHERE r.post_id = p.id AND r.user_id = ?
          )
    ''', params).fetchone()
    db.close()
    return row['cnt'] if row else 0

# ── 게시판 허브 ───────────────────────────────────────
@board_bp.route('/')
@login_required
def hub():
    user_id = session['user_id']
    cutoff  = three_days_ago_str()
    db = get_db()

    stats = {}
    for cat_key in CATEGORIES:
        recent_posts = db.execute('''
            SELECT p.id, p.title, p.created_at, u.name as author_name
            FROM board_posts p
            JOIN users u ON p.author_id = u.id
            WHERE p.category = ?
              AND p.created_at >= ?
            ORDER BY p.created_at DESC
            LIMIT 3
        ''', (cat_key, cutoff)).fetchall()

        stats[cat_key] = {
            'recent_posts': [dict(r) for r in recent_posts],
        }
    db.close()
    return render_template('board/hub.html',
                           categories=CATEGORIES,
                           stats=stats)

# ── 게시글 목록 ───────────────────────────────────────
@board_bp.route('/<category>')
@login_required
def list_posts(category):
    if category not in CATEGORIES:
        flash('존재하지 않는 게시판입니다.', 'error')
        return redirect(url_for('board.hub'))

    cat_info = CATEGORIES[category]
    user_id  = session['user_id']
    keyword  = request.args.get('q', '').strip()
    page     = request.args.get('page', 1, type=int)
    per_page = 20

    where  = ["p.category=?"]
    params = [category]
    if keyword:
        where.append("(p.title LIKE ? OR p.content LIKE ?)")
        kw = f'%{keyword}%'
        params += [kw, kw]

    db = get_db()
    total = db.execute(
        f"SELECT COUNT(*) FROM board_posts p WHERE {' AND '.join(where)}", params
    ).fetchone()[0]

    # 읽음 여부 함께 조회 (사내/팀 공지만)
    if category in READ_TRACK_CATEGORIES:
        posts = db.execute(f'''
            SELECT p.*, u.name as author_name,
                   (SELECT COUNT(*) FROM board_comments c WHERE c.post_id=p.id) as comment_count,
                   (SELECT COUNT(*) FROM board_attachments a WHERE a.post_id=p.id) as attach_count,
                   (SELECT COUNT(*) FROM board_reads r WHERE r.post_id=p.id AND r.user_id=?) as is_read
            FROM board_posts p
            JOIN users u ON p.author_id = u.id
            WHERE {' AND '.join(where)}
            ORDER BY p.is_pinned DESC, p.created_at DESC
            LIMIT ? OFFSET ?
        ''', [user_id] + params + [per_page, (page - 1) * per_page]).fetchall()
    else:
        posts = db.execute(f'''
            SELECT p.*, u.name as author_name,
                   (SELECT COUNT(*) FROM board_comments c WHERE c.post_id=p.id) as comment_count,
                   (SELECT COUNT(*) FROM board_attachments a WHERE a.post_id=p.id) as attach_count,
                   0 as is_read
            FROM board_posts p
            JOIN users u ON p.author_id = u.id
            WHERE {' AND '.join(where)}
            ORDER BY p.is_pinned DESC, p.created_at DESC
            LIMIT ? OFFSET ?
        ''', params + [per_page, (page - 1) * per_page]).fetchall()

    # 읽음 현황 (사내/팀 공지 - 게시글별 읽은 인원 수)
    read_counts = {}
    total_users = 0
    if category in READ_TRACK_CATEGORIES:
        total_users = db.execute(
            "SELECT COUNT(*) FROM users WHERE is_active=1"
        ).fetchone()[0]
        for post in posts:
            cnt = db.execute(
                "SELECT COUNT(*) FROM board_reads WHERE post_id=?", (post['id'],)
            ).fetchone()[0]
            read_counts[post['id']] = cnt

    flex_cfg = {}
    if category == 'company_notice':
        row = db.execute("SELECT * FROM flex_config ORDER BY id DESC LIMIT 1").fetchone()
        flex_cfg = dict(row) if row else {}

    total_pages = (total + per_page - 1) // per_page
    db.close()

    return render_template('board/list.html',
                           category=category,
                           cat_info=cat_info,
                           categories=CATEGORIES,
                           posts=posts,
                           keyword=keyword,
                           page=page,
                           total=total,
                           total_pages=total_pages,
                           flex_cfg=flex_cfg,
                           can_write=can_write(category),
                           read_counts=read_counts,
                           total_users=total_users,
                           file_size_str=file_size_str)

# ── 게시글 상세 ───────────────────────────────────────
@board_bp.route('/post/<int:post_id>')
@login_required
def view_post(post_id):
    db = get_db()
    db.execute("UPDATE board_posts SET view_count=view_count+1 WHERE id=?", (post_id,))

    post = db.execute('''
        SELECT p.*, u.name as author_name
        FROM board_posts p
        JOIN users u ON p.author_id = u.id
        WHERE p.id=?
    ''', (post_id,)).fetchone()

    if not post:
        flash('게시글을 찾을 수 없습니다.', 'error')
        db.close()
        return redirect(url_for('board.hub'))

    # 읽음 처리 (사내/팀 공지)
    if post['category'] in READ_TRACK_CATEGORIES:
        mark_as_read(db, post_id, session['user_id'])

    db.commit()

    cat_info = CATEGORIES.get(post['category'], {})
    category = post['category']

    comments = []
    if cat_info.get('comment', True):
        comments = db.execute('''
            SELECT c.*, u.name as author_name
            FROM board_comments c
            JOIN users u ON c.author_id = u.id
            WHERE c.post_id=?
            ORDER BY c.created_at ASC
        ''', (post_id,)).fetchall()

    attachments = db.execute(
        "SELECT * FROM board_attachments WHERE post_id=? ORDER BY id",
        (post_id,)
    ).fetchall()

    # 사이드바 글 목록 (같은 카테고리 최신 20개, 현재 글 강조용)
    sidebar_posts = db.execute('''
        SELECT id, title,
               (SELECT COUNT(*) FROM board_attachments a WHERE a.post_id=p.id) as attach_count
        FROM board_posts p
        WHERE category=?
        ORDER BY created_at DESC
        LIMIT 20
    ''', (category,)).fetchall()

    db.close()
    return render_template('board/detail.html',
                           post=post,
                           cat_info=cat_info,
                           categories=CATEGORIES,
                           comments=comments,
                           attachments=attachments,
                           sidebar_posts=sidebar_posts,
                           can_delete=can_delete_post(post),
                           file_size_str=file_size_str,
                           get_file_icon=get_file_icon)

# ── 읽음 현황 상세 (팝업용) ──────────────────────────
@board_bp.route('/post/<int:post_id>/reads')
@login_required
def post_reads(post_id):
    db = get_db()
    post = db.execute(
        "SELECT id, title, category FROM board_posts WHERE id=?", (post_id,)
    ).fetchone()

    if not post or post['category'] not in READ_TRACK_CATEGORIES:
        db.close()
        return redirect(url_for('board.hub'))

    # 읽은 사람
    read_users = db.execute('''
        SELECT u.name, u.location, r.read_at
        FROM board_reads r
        JOIN users u ON r.user_id = u.id
        WHERE r.post_id = ?
        ORDER BY r.read_at ASC
    ''', (post_id,)).fetchall()

    # 안 읽은 사람
    unread_users = db.execute('''
        SELECT u.name, u.location
        FROM users u
        WHERE u.is_active = 1
          AND NOT EXISTS (
              SELECT 1 FROM board_reads r
              WHERE r.post_id = ? AND r.user_id = u.id
          )
        ORDER BY u.location, u.name
    ''', (post_id,)).fetchall()

    total_active = db.execute(
        "SELECT COUNT(*) FROM users WHERE is_active=1"
    ).fetchone()[0]

    db.close()
    return render_template('board/reads.html',
                           post=post,
                           categories=CATEGORIES,
                           read_users=read_users,
                           unread_users=unread_users,
                           total_active=total_active)

# ── 게시글 작성 ───────────────────────────────────────
@board_bp.route('/<category>/write', methods=['GET', 'POST'])
@login_required
def write_post(category):
    if category not in CATEGORIES:
        flash('존재하지 않는 게시판입니다.', 'error')
        return redirect(url_for('board.hub'))

    if not can_write(category):
        flash('이 게시판에 글을 작성할 권한이 없습니다.', 'error')
        return redirect(url_for('board.list_posts', category=category))

    cat_info = CATEGORIES[category]

    if request.method == 'POST':
        title   = request.form.get('title', '').strip()
        content = request.form.get('content', '').strip()

        if not title:
            flash('제목을 입력해주세요.', 'error')
            return render_template('board/form.html', action='write', post=None,
                                   category=category, cat_info=cat_info,
                                   categories=CATEGORIES, attachments=[])
        if not content:
            flash('내용을 입력해주세요.', 'error')
            return render_template('board/form.html', action='write', post=None,
                                   category=category, cat_info=cat_info,
                                   categories=CATEGORIES, attachments=[])

        db = get_db()
        db.execute('''
            INSERT INTO board_posts (category, title, content, author_id)
            VALUES (?, ?, ?, ?)
        ''', (category, title, content, session['user_id']))
        post_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]
        _save_attachments(db, post_id, request.files.getlist('files'))
        db.commit()
        db.close()
        flash('✅ 게시글이 등록되었습니다.', 'success')
        return redirect(url_for('board.view_post', post_id=post_id))

    return render_template('board/form.html', action='write', post=None,
                           category=category, cat_info=cat_info,
                           categories=CATEGORIES, attachments=[])

# ── 게시글 수정 ───────────────────────────────────────
@board_bp.route('/post/<int:post_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_post(post_id):
    db = get_db()
    post = db.execute("SELECT * FROM board_posts WHERE id=?", (post_id,)).fetchone()

    if not post:
        flash('게시글을 찾을 수 없습니다.', 'error')
        db.close()
        return redirect(url_for('board.hub'))

    if post['is_flex']:
        flash('Flex 연동 공지는 수정할 수 없습니다.', 'error')
        db.close()
        return redirect(url_for('board.view_post', post_id=post_id))

    category = post['category']
    cat_info = CATEGORIES.get(category, {})

    if post['author_id'] != session['user_id'] and session.get('role') != 'admin':
        flash('수정 권한이 없습니다.', 'error')
        db.close()
        return redirect(url_for('board.view_post', post_id=post_id))

    if request.method == 'POST':
        title   = request.form.get('title', '').strip()
        content = request.form.get('content', '').strip()

        if not title or not content:
            flash('제목과 내용을 입력해주세요.', 'error')
            attachments = db.execute(
                "SELECT * FROM board_attachments WHERE post_id=?", (post_id,)
            ).fetchall()
            db.close()
            return render_template('board/form.html', action='edit', post=post,
                                   category=category, cat_info=cat_info,
                                   categories=CATEGORIES, attachments=attachments)

        db.execute('''
            UPDATE board_posts
            SET title=?, content=?, updated_at=datetime('now','localtime')
            WHERE id=?
        ''', (title, content, post_id))

        for aid in request.form.getlist('delete_attach'):
            att = db.execute(
                "SELECT saved_name FROM board_attachments WHERE id=?", (aid,)
            ).fetchone()
            if att:
                try:
                    os.remove(os.path.join(UPLOAD_DIR, att['saved_name']))
                except Exception:
                    pass
                db.execute("DELETE FROM board_attachments WHERE id=?", (aid,))

        _save_attachments(db, post_id, request.files.getlist('files'))
        db.commit()
        db.close()
        flash('✅ 게시글이 수정되었습니다.', 'success')
        return redirect(url_for('board.view_post', post_id=post_id))

    attachments = db.execute(
        "SELECT * FROM board_attachments WHERE post_id=?", (post_id,)
    ).fetchall()
    db.close()
    return render_template('board/form.html', action='edit', post=post,
                           category=category, cat_info=cat_info,
                           categories=CATEGORIES, attachments=attachments)

# ── 게시글 삭제 ───────────────────────────────────────
@board_bp.route('/post/<int:post_id>/delete', methods=['POST'])
@login_required
def delete_post(post_id):
    db = get_db()
    post = db.execute("SELECT * FROM board_posts WHERE id=?", (post_id,)).fetchone()

    if not post:
        db.close()
        return redirect(url_for('board.hub'))

    if not can_delete_post(post):
        flash('삭제 권한이 없습니다.', 'error')
        db.close()
        return redirect(url_for('board.view_post', post_id=post_id))

    category = post['category']
    atts = db.execute(
        "SELECT saved_name FROM board_attachments WHERE post_id=?", (post_id,)
    ).fetchall()
    for att in atts:
        try:
            os.remove(os.path.join(UPLOAD_DIR, att['saved_name']))
        except Exception:
            pass

    db.execute("DELETE FROM board_reads WHERE post_id=?", (post_id,))
    db.execute("DELETE FROM board_attachments WHERE post_id=?", (post_id,))
    db.execute("DELETE FROM board_comments WHERE post_id=?", (post_id,))
    db.execute("DELETE FROM board_posts WHERE id=?", (post_id,))
    db.commit()
    db.close()
    flash('🗑️ 게시글이 삭제되었습니다.', 'success')
    return redirect(url_for('board.list_posts', category=category))

# ── 댓글 작성 ─────────────────────────────────────────
@board_bp.route('/post/<int:post_id>/comment', methods=['POST'])
@login_required
def add_comment(post_id):
    content = request.form.get('content', '').strip()
    if not content:
        flash('댓글 내용을 입력해주세요.', 'error')
        return redirect(url_for('board.view_post', post_id=post_id))

    db = get_db()
    post = db.execute("SELECT category FROM board_posts WHERE id=?", (post_id,)).fetchone()
    if post:
        cat_info = CATEGORIES.get(post['category'], {})
        if not cat_info.get('comment', True):
            flash('이 게시판에서는 댓글을 사용할 수 없습니다.', 'error')
            db.close()
            return redirect(url_for('board.view_post', post_id=post_id))

    db.execute('''
        INSERT INTO board_comments (post_id, author_id, content)
        VALUES (?, ?, ?)
    ''', (post_id, session['user_id'], content))
    db.commit()
    db.close()
    return redirect(url_for('board.view_post', post_id=post_id) + '#comments')

# ── 댓글 삭제 ─────────────────────────────────────────
@board_bp.route('/comment/<int:comment_id>/delete', methods=['POST'])
@login_required
def delete_comment(comment_id):
    db = get_db()
    comment = db.execute(
        "SELECT * FROM board_comments WHERE id=?", (comment_id,)
    ).fetchone()

    if comment and (comment['author_id'] == session['user_id']
                    or session.get('role') == 'admin'):
        post_id = comment['post_id']
        db.execute("DELETE FROM board_comments WHERE id=?", (comment_id,))
        db.commit()
        db.close()
        return redirect(url_for('board.view_post', post_id=post_id) + '#comments')

    db.close()
    flash('삭제 권한이 없습니다.', 'error')
    return redirect(url_for('board.hub'))

# ── 파일 다운로드 ─────────────────────────────────────
@board_bp.route('/download/<int:attach_id>')
@login_required
def download_file(attach_id):
    db = get_db()
    att = db.execute(
        "SELECT * FROM board_attachments WHERE id=?", (attach_id,)
    ).fetchone()
    db.close()

    if not att:
        abort(404)

    file_path = os.path.join(UPLOAD_DIR, att['saved_name'])
    if not os.path.exists(file_path):
        flash('파일을 찾을 수 없습니다. 서버에서 삭제된 파일입니다.', 'error')
        return redirect(request.referrer or url_for('board.hub'))

    return send_from_directory(
        UPLOAD_DIR,
        att['saved_name'],
        as_attachment=True,
        download_name=att['filename']
    )

# ── Flex 동기화 (관리자) ──────────────────────────────
@board_bp.route('/admin/flex/sync', methods=['POST'])
@login_required
@admin_required
def flex_sync():
    count, err = sync_flex_notices()
    if err:
        flash(f'❌ Flex 동기화 실패: {err}', 'error')
    else:
        if count > 0:
            flash(f'✅ Flex에서 공지 {count}건을 가져왔습니다.', 'success')
        else:
            flash('ℹ️ 새로운 Flex 공지가 없습니다.', 'info')
    return redirect(url_for('board.list_posts', category='company_notice'))

# ── Flex 설정 (관리자) ────────────────────────────────
@board_bp.route('/admin/flex/config', methods=['GET', 'POST'])
@login_required
@admin_required
def flex_config():
    db = get_db()
    cfg = db.execute(
        "SELECT * FROM flex_config ORDER BY id DESC LIMIT 1"
    ).fetchone()

    if request.method == 'POST':
        api_url    = request.form.get('api_url', '').strip()
        api_key    = request.form.get('api_key', '').strip()
        is_enabled = 1 if request.form.get('is_enabled') else 0

        existing = db.execute("SELECT id FROM flex_config LIMIT 1").fetchone()
        if existing:
            db.execute('''
                UPDATE flex_config
                SET api_url=?, api_key=?, is_enabled=?,
                    updated_at=datetime('now','localtime')
            ''', (api_url, api_key, is_enabled))
        else:
            db.execute('''
                INSERT INTO flex_config (api_url, api_key, is_enabled)
                VALUES (?, ?, ?)
            ''', (api_url, api_key, is_enabled))
        db.commit()
        db.close()
        flash('✅ Flex 연동 설정이 저장되었습니다.', 'success')
        return redirect(url_for('board.flex_config'))

    db.close()
    return render_template('board/flex_config.html',
                           cfg=cfg, categories=CATEGORIES)

# ── 내부 헬퍼: 첨부파일 저장 ─────────────────────────
def _save_attachments(db, post_id, files):
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    for file in files:
        if not file or not file.filename:
            continue
        if not allowed_file(file.filename):
            flash(f'허용되지 않는 파일 형식입니다: {file.filename}', 'error')
            continue
        content_bytes = file.read()
        if len(content_bytes) > MAX_FILE_SIZE:
            flash(f'파일 크기 초과 (최대 50MB): {file.filename}', 'error')
            continue
        if len(content_bytes) == 0:
            continue
        ext       = file.filename.rsplit('.', 1)[1].lower()
        saved     = f"{uuid.uuid4().hex}.{ext}"
        save_path = os.path.join(UPLOAD_DIR, saved)
        with open(save_path, 'wb') as f:
            f.write(content_bytes)
        db.execute('''
            INSERT INTO board_attachments (post_id, filename, saved_name, file_size)
            VALUES (?, ?, ?, ?)
        ''', (post_id, file.filename, saved, len(content_bytes)))
