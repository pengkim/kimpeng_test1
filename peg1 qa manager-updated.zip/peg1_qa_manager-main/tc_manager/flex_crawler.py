"""
flex_crawler.py
Flex(flex.team) 공지사항을 Playwright로 수집해서 DB에 저장.

필요 패키지 설치:
    pip install playwright apscheduler python-dotenv
    playwright install chromium
"""

import os
import logging
import datetime
import threading
from dotenv import load_dotenv

load_dotenv(os.path.join(os.path.dirname(__file__), '.env'))

logger = logging.getLogger('flex_crawler')

FLEX_LOGIN_URL  = 'https://flex.team/auth/login'
FLEX_NOTICE_URL = 'https://flex.team/home/news-feed/notice'

# ── DB 연동 ──────────────────────────────────────────
def get_db():
    import sqlite3
    db_path = os.path.join(os.path.dirname(__file__), 'tc_manager.db')
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn


def get_flex_credentials():
    """DB 또는 .env에서 Flex 계정 정보 읽기"""
    # 1순위: DB flex_config 테이블
    try:
        db = get_db()
        cfg = db.execute(
            "SELECT * FROM flex_config ORDER BY id DESC LIMIT 1"
        ).fetchone()
        db.close()
        if cfg and cfg['api_key'] and cfg['api_url']:
            # api_url = email, api_key = password 로 임시 저장한 경우
            return cfg['api_url'], cfg['api_key']
    except Exception:
        pass

    # 2순위: .env 파일
    email = os.environ.get('FLEX_EMAIL', '')
    password = os.environ.get('FLEX_PASSWORD', '')
    return email, password


def save_notice_to_db(title, content, flex_id, published_at):
    """
    수집한 공지를 board_posts에 저장.
    flex_id로 중복 방지.
    """
    try:
        db = get_db()
        # 이미 존재하면 스킵
        exists = db.execute(
            "SELECT id FROM board_posts WHERE flex_id=?", (flex_id,)
        ).fetchone()
        if exists:
            db.close()
            return False

        # 관리자 ID
        admin = db.execute(
            "SELECT id FROM users WHERE role='admin' LIMIT 1"
        ).fetchone()
        author_id = admin['id'] if admin else 1

        db.execute('''
            INSERT INTO board_posts
                (category, title, content, author_id, is_flex, flex_id,
                 created_at, updated_at)
            VALUES (?, ?, ?, ?, 1, ?, ?, ?)
        ''', (
            'company_notice',
            title,
            content,
            author_id,
            flex_id,
            published_at,
            published_at,
        ))

        # last_sync 갱신
        db.execute(
            "UPDATE flex_config SET last_sync=datetime('now','localtime')"
        )
        db.commit()
        db.close()
        return True
    except Exception as e:
        logger.error(f'DB 저장 오류: {e}')
        return False


# ── Playwright 크롤러 ─────────────────────────────────
def crawl_flex_notices():
    """
    Playwright로 Flex에 로그인 후 공지사항 수집.
    반환: (성공 건수, 오류 메시지 or None)
    """
    email, password = get_flex_credentials()
    if not email or not password:
        return 0, '.env 파일에 FLEX_EMAIL, FLEX_PASSWORD를 설정해주세요.'

    try:
        from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout
    except ImportError:
        return 0, 'playwright가 설치되지 않았습니다. (pip install playwright && playwright install chromium)'

    count = 0
    error_msg = None

    try:
        with sync_playwright() as pw:
            browser = pw.chromium.launch(
                headless=True,
                args=['--no-sandbox', '--disable-dev-shm-usage'],
            )
            ctx = browser.new_context(
                viewport={'width': 1280, 'height': 800},
                user_agent=(
                    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                    'AppleWebKit/537.36 (KHTML, like Gecko) '
                    'Chrome/120.0.0.0 Safari/537.36'
                ),
            )
            page = ctx.new_page()

            # ── 1. 로그인 ──────────────────────────────
            logger.info('Flex 로그인 시도...')
            page.goto(FLEX_LOGIN_URL, wait_until='networkidle', timeout=30000)

            # 이메일 입력
            page.wait_for_selector('input[type="email"], input[name="email"], input[placeholder*="이메일"], input[placeholder*="Email"]', timeout=10000)
            page.fill('input[type="email"], input[name="email"], input[placeholder*="이메일"], input[placeholder*="Email"]', email)

            # 비밀번호 입력
            page.fill('input[type="password"]', password)

            # 로그인 버튼 클릭
            page.click('button[type="submit"], button:has-text("로그인"), button:has-text("Login")')

            # 로그인 완료 대기
            try:
                page.wait_for_url('**/home/**', timeout=15000)
            except PWTimeout:
                # URL 변경 안되도 계속 시도
                page.wait_for_timeout(3000)

            logger.info('로그인 완료')

            # ── 2. 공지사항 페이지 이동 ────────────────
            page.goto(FLEX_NOTICE_URL, wait_until='networkidle', timeout=30000)
            page.wait_for_timeout(2000)

            # ── 3. 공지 목록 수집 ──────────────────────
            # Flex 공지 아이템 선택자 (실제 DOM 구조에 따라 조정 필요)
            # 일반적인 패턴들을 순서대로 시도
            selectors = [
                'article',
                '[class*="notice-item"]',
                '[class*="post-item"]',
                '[class*="feed-item"]',
                '[class*="NewsItem"]',
                '[class*="notice"]',
                'li[class*="item"]',
            ]

            items = []
            for sel in selectors:
                found = page.query_selector_all(sel)
                if found and len(found) > 0:
                    items = found
                    logger.info(f'공지 아이템 {len(items)}개 발견 (selector: {sel})')
                    break

            if not items:
                # 페이지 전체 텍스트로 디버그
                logger.warning('공지 아이템을 찾지 못했습니다. 페이지 구조를 확인하세요.')
                # 스크린샷 저장 (디버깅용)
                ss_path = os.path.join(os.path.dirname(__file__), 'flex_debug.png')
                page.screenshot(path=ss_path)
                logger.info(f'디버그 스크린샷 저장: {ss_path}')
                browser.close()
                return 0, '공지 아이템을 찾지 못했습니다. flex_debug.png를 확인하세요.'

            # 각 아이템에서 제목/내용/날짜 추출
            for i, item in enumerate(items[:20]):  # 최대 20개
                try:
                    # 제목 추출
                    title_el = (
                        item.query_selector('h1, h2, h3, h4, [class*="title"], [class*="subject"]')
                    )
                    title = title_el.inner_text().strip() if title_el else ''
                    if not title:
                        # 전체 텍스트 첫 줄
                        full_text = item.inner_text().strip()
                        title = full_text.split('\n')[0][:100] if full_text else f'공지 {i+1}'

                    # 내용 추출
                    content_el = item.query_selector('[class*="content"], [class*="body"], p')
                    if content_el:
                        content = content_el.inner_text().strip()
                    else:
                        full = item.inner_text().strip()
                        lines = full.split('\n')
                        content = '\n'.join(lines[1:]).strip() if len(lines) > 1 else full

                    # 날짜 추출
                    date_el = item.query_selector('time, [class*="date"], [class*="time"], [datetime]')
                    if date_el:
                        dt_attr = date_el.get_attribute('datetime')
                        if dt_attr:
                            try:
                                published_at = datetime.datetime.fromisoformat(
                                    dt_attr.replace('Z', '+00:00')
                                ).strftime('%Y-%m-%d %H:%M:%S')
                            except Exception:
                                published_at = date_el.inner_text().strip() or datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                        else:
                            published_at = date_el.inner_text().strip() or datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                    else:
                        published_at = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

                    # flex_id: URL hash 또는 인덱스 기반
                    href = ''
                    link_el = item.query_selector('a[href]')
                    if link_el:
                        href = link_el.get_attribute('href') or ''
                    flex_id = href if href else f'flex_notice_{title[:30]}_{published_at[:10]}'

                    if title:
                        saved = save_notice_to_db(title, content or title, flex_id, published_at)
                        if saved:
                            count += 1
                            logger.info(f'저장: {title[:40]}')

                except Exception as e:
                    logger.warning(f'아이템 {i} 파싱 오류: {e}')
                    continue

            browser.close()

    except Exception as e:
        error_msg = str(e)
        logger.error(f'Flex 크롤링 오류: {error_msg}')

    return count, error_msg


# ── 스케줄러 ──────────────────────────────────────────
_scheduler_started = False
_scheduler_lock = threading.Lock()


def start_scheduler(app=None):
    """
    백그라운드 스케줄러 시작.
    Flask app context가 필요하면 app 인자 전달.
    """
    global _scheduler_started

    with _scheduler_lock:
        if _scheduler_started:
            return
        _scheduler_started = True

    interval_min = int(os.environ.get('FLEX_SYNC_INTERVAL_MINUTES', 60))

    try:
        # APScheduler 방식 (설치된 경우)
        from apscheduler.schedulers.background import BackgroundScheduler
        scheduler = BackgroundScheduler(daemon=True)

        def job():
            logger.info(f'[스케줄] Flex 공지 수집 시작...')
            count, err = crawl_flex_notices()
            if err:
                logger.error(f'[스케줄] 오류: {err}')
            else:
                logger.info(f'[스케줄] 완료: {count}건 저장')

        # 앱 시작 1분 후 첫 실행, 이후 interval_min마다
        scheduler.add_job(job, 'interval', minutes=interval_min,
                          next_run_time=datetime.datetime.now() + datetime.timedelta(minutes=1))
        scheduler.start()
        logger.info(f'APScheduler 시작 (주기: {interval_min}분)')

    except ImportError:
        # APScheduler 없으면 threading.Timer로 fallback
        logger.info(f'threading.Timer 방식으로 스케줄 시작 (주기: {interval_min}분)')
        _run_with_timer(interval_min)


def _run_with_timer(interval_min):
    """APScheduler 없을 때 threading.Timer로 반복 실행"""
    def job():
        logger.info('[스케줄] Flex 공지 수집 시작...')
        count, err = crawl_flex_notices()
        if err:
            logger.error(f'[스케줄] 오류: {err}')
        else:
            logger.info(f'[스케줄] 완료: {count}건 저장')
        # 다음 실행 예약
        t = threading.Timer(interval_min * 60, job)
        t.daemon = True
        t.start()

    # 1분 후 첫 실행
    t = threading.Timer(60, job)
    t.daemon = True
    t.start()


if __name__ == '__main__':
    # 단독 실행 테스트
    logging.basicConfig(level=logging.INFO)
    print('Flex 공지 수집 테스트...')
    count, err = crawl_flex_notices()
    if err:
        print(f'오류: {err}')
    else:
        print(f'완료: {count}건 저장')
